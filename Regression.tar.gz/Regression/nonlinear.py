import numpy as np
import matplotlib.pyplot as plt
import scipy.io.wavfile as sci
from scipy.fftpack import fft
from scipy.fftpack import dct
import math

## Initialization
no_v_units = 4
no_h_units = 9
no_o_units = 3
eps = 0.001
Maxepoch = 1000
lamda = 0.0001
initialmomentum = 0.5
finalmomentum = 0.9

z = np.arange(1,301); n = len(z)

w1 = np.random.randn(no_h_units,no_v_units)
w2 = np.random.randn(no_o_units,no_h_units)
dw1 = np.zeros((no_h_units,no_v_units))
dw2 = np.zeros((no_o_units,no_h_units))
t_test = np.zeros((3,100))

## Pre-processing
ra = 0.9; rb = 0.1
meas = ((((ra-rb)*(z-np.amin(z)))/(np.amax(z)-np.amin(z)))+rb).reshape((100,3))
batch_size = 10
batches = 10
x0 = np.ones((batch_size,1))
x = meas[:,0].reshape((100,1))
y = meas[:,1].reshape((100,1))
z = meas[:,2].reshape((100,1))

## Original equations and then normalized
a1=2; b1=5; c1=1; a2=1; b2=6; c2=1; a3=4; b3=3; c3=1;
f1 = a1*np.power(x, 2) + np.random.randn(100,1)*0.1
f2 = a2*x #+ b2*np.power(y, 2) + c2
f3 = a3*np.power(x, 2) + c2*z

f1 = ((((ra-rb)*(f1-np.amin(f1)))/(np.amax(f1)-np.amin(f1)))+rb).reshape((100,1))
f2 = ((((ra-rb)*(f2-np.amin(f2)))/(np.amax(f2)-np.amin(f2)))+rb).reshape((100,1))
f3 = ((((ra-rb)*(f3-np.amin(f3)))/(np.amax(f3)-np.amin(f3)))+rb).reshape((100,1))
t_test = np.concatenate((f1,f2,f3), axis=1)
t_test = np.transpose(t_test) # 3x100

def sigmoid(z):
	g = 1/(1+np.exp(z))
	return g

def sigmoid_diff(g):
	diff = np.multiply(g,(1-g))
	return diff

def Nonlin_test(meas,w1,w2,t_test):
	I = np.concatenate((np.ones((100,1)),meas), axis=1) # 100x4
	hid_act = sigmoid(np.dot(w1,np.transpose(I))) # 9x100
	y = sigmoid(np.dot(w2,hid_act)); # 3x10, predicted y
	return y


## FNN
temp1 = np.zeros((10,3))
delt3 = np.zeros((3,10))
delta2 = np.zeros((9,10))
grad_w1 = np.zeros((9,4))
grad_w2 = np.zeros((3,9))
dw1 = np.zeros((9,4))
dw2 = np.zeros((3,9))
y_test = np.zeros((3,100))
C_mat = [];

for epoch in range(0,Maxepoch):
	temp = 0
	if epoch <= 5:
		momentum = initialmomentum;
	else:
		momentum = finalmomentum;

	for i in range(0,batches):
		temp1 = meas[temp:10+temp,:] # 10x3
		I = np.concatenate((x0,temp1),axis=1) # 10x4
		hid_act = sigmoid(np.dot(w1,np.transpose(I))) # 9x10
		y = sigmoid(np.dot(w2,hid_act)); # 3x10, predicted y

		t = np.concatenate((f1[temp:10+temp,:], f2[temp:10+temp,:], f3[temp:10+temp,:]), axis=1) 
		t = np.transpose(t) # 3x10, original y

		# cross entropy function
		C = (-1/10)*np.sum(np.sum(np.multiply(t,np.log(y)) + np.multiply((1-t),np.log(1-y))))

		# Back-propogation
		delta3 = y-t # 3x10
		delta2 = sigmoid_diff(np.multiply(hid_act,np.dot(np.transpose(w2),delta3))) # 9x10
		grad_w1 = np.dot(delta2,I) + (lamda*w1)
		grad_w2 = np.dot(delta3,np.transpose(hid_act)) + (lamda*w2)

		# Weight-updation
		dw1 = (-eps*grad_w1/batch_size) + (momentum*dw1)
		dw2 = (-eps*grad_w2/batch_size) + (momentum*dw2)
		w1 = w1+dw1
		w2 = w2+dw2

		temp = temp+batch_size
		del temp1
	C_mat = np.append(C_mat,C)

	## Training
	if epoch%30 == 0:
		fig = plt.figure()
		ax1 = fig.add_subplot(311)
		ax2 = fig.add_subplot(312)
		ax3 = fig.add_subplot(313)

		print epoch
		y_test = Nonlin_test(meas,w1,w2,t_test)

		ax1.plot(t_test[0,:],'-r', label='measured')
		ax1.plot(True)
		ax1.plot(y_test[0,:],'ob', label='predicted')
		ax1.plot(False)
		ax1.title.set_text('F1 = 2(x^2)+noise')

		ax2.plot(t_test[1,:],'-r', label='measured')
		ax2.plot(True)
		ax2.plot(y_test[1,:],'ob', label='predicted')
		ax2.plot(False)
		ax2.title.set_text('F2 = x+6(y^2)+1')

		ax3.plot(t_test[2,:],'-r', label='measured')
		ax3.plot(True)
		ax3.plot(y_test[2,:],'ob', label='predicted')
		ax3.plot(False)
		ax3.title.set_text('F3 = 4(x^2)+z')
		plt.show()
		plt.close('all')

fig = plt.figure()
plt.plot(C_mat)
plt.xlabel('Epoch')
plt.ylabel('Error')
plt.title('Cross Entropy error function')
plt.show()
		
