def sigmoid_pyt(z):
	g = float(1)/float(1+exp(z))
	return g
	