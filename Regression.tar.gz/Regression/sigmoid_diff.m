function [ diff ] = sigmoid_diff( g )
% takes input as activation function, i.e. input from sigmoid.m file and
% give its derivative as output
diff = g .* (1-g) ;
end

