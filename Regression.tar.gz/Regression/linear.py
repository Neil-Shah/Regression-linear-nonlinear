import numpy as np
import matplotlib.pyplot as plt
import math
import random

## Initialization
no_v_units = 2
eps = 0.001
Maxepoch = 1000
lamda = 0.00001
initialmomentum = 0.5
finalmomentum = 0.9
# random.seed(300)
a = 1.5
b = 0.5
z = np.arange(1,301) #300 points
n = len(z)
batch_size = 10
batches = int(n/batch_size)
x0 = np.ones((batch_size,1),dtype = np.int)
w = np.random.randn(no_v_units,1)
w_ini = w
temp1_tr = np.random.randn(batch_size,1)*0.1
temp1_te = np.random.randn(n,1)*0.1


## Pre-processing
x = np.zeros((n,1))
for i in range(0,n):
	x[i] = float(z[i]-min(z))/float(max(z)-min(z)) 
x_temp = x # n x 1

temp2 = 0
bat = np.zeros((batches,batch_size))
for i in range(0,batches):
	bat[i,:] = np.transpose(x[temp2:batch_size+temp2,:])
	temp2 = temp2+batch_size

## Feed-forward
temp3 = np.random.permutation(batches) # random index
w_temp = 1000000 * np.ones((no_v_units,1))

t = np.zeros((batch_size,1))
y = np.zeros((batch_size,1))
y_train = np.zeros((n,1))
error = np.zeros((batch_size,1))
t_train = np.zeros((n,1))
I_train = np.zeros((n,2))
dw = np.zeros((no_v_units,1))

for epoch in range(0,Maxepoch):
	if epoch <= 5:
		momentum = initialmomentum
	else:
		momentum = finalmomentum
	for i in range(0,batches):
		temp4 = temp3[i]
		x = np.transpose(bat[temp4,:]).reshape((10,1))
		t = a*x+b#+temp1_tr
		ts = len(t)
		I = np.concatenate((x0,x),axis = 1) # batch_size x 2
		y = np.dot(I,w) # 10x2,2x1 = 10x1

		error = t-y # 10x1
		grad = (-2*np.dot(np.transpose(I),error)+ lamda*w)/(ts) # scalar
		dw = (-eps*grad) + (momentum*dw)
		w = w + dw
		del I

	if np.all(abs(w-w_temp)) <= 0.0000001:
		break
	
	w_temp = w
	if epoch%20 == 0:
		fig = plt.figure()
		print epoch
		t_train = a*x_temp+b#+temp1_te
		x0_1 = np.ones((n,1))
		I_train = np.concatenate((x0_1,x_temp),axis = 1) # n x 2
		y_train = np.dot(I_train,w) # n x 1

		plt.plot(t_train,'-r', label='measured')
		plt.plot(True)
		plt.plot(y_train,'ob', label='predicted')
		plt.plot(False)
		plt.legend(loc='upper right')
		plt.xlabel('Examples')
		plt.title('Regression for ax+b+noise')
		plt.show()
		plt.close('all')

			